"""
Retriever: Stores chunks + embeddings in ChromaDB and handles similarity search.

ChromaDB is like a local filing cabinet where each folder (chunk) has a
magnetic label (embedding). When you ask a question, we magnetize your
question the same way and see which folders stick.
"""

import chromadb
from pathlib import Path

from src.chunker import Chunk


def get_collection(
    db_dir: Path,
    collection_name: str,
):
    """Get or create a ChromaDB collection with persistent storage."""
    client = chromadb.PersistentClient(path=str(db_dir))
    collection = client.get_or_create_collection(
        name=collection_name,
        metadata={"hnsw:space": "cosine"},  # cosine similarity
    )
    return collection


def store_chunks(
    collection,
    chunks: list[Chunk],
    embeddings: list[list[float]],
):
    """
    Store all chunks with their embeddings and metadata in ChromaDB.
    Uses upsert so re-running ingestion is safe (idempotent).
    """
    # ChromaDB has a batch limit, process in groups
    BATCH = 500

    for i in range(0, len(chunks), BATCH):
        batch_chunks = chunks[i:i + BATCH]
        batch_embeddings = embeddings[i:i + BATCH]

        collection.upsert(
            ids=[c.id for c in batch_chunks],
            documents=[c.text for c in batch_chunks],
            embeddings=batch_embeddings,
            metadatas=[
                {
                    "page_number": c.page_number,
                    "chunk_index": c.chunk_index,
                    "token_count": c.token_count,
                }
                for c in batch_chunks
            ],
        )

        print(f"  Stored batch {i // BATCH + 1}"
              f" ({min(i + BATCH, len(chunks))}/{len(chunks)} chunks)")

    print(f"Total documents in collection: {collection.count()}")


def query_similar(
    collection,
    query_embedding: list[float],
    n_results: int = 5,
) -> list[dict]:
    """
    Find the most similar chunks to a query embedding.
    Returns a list of dicts with text, page_number, and similarity score.
    """
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=n_results,
        include=["documents", "metadatas", "distances"],
    )

    hits = []
    for i in range(len(results["ids"][0])):
        hits.append({
            "id": results["ids"][0][i],
            "text": results["documents"][0][i],
            "page_number": results["metadatas"][0][i]["page_number"],
            "distance": results["distances"][0][i],
        })

    return hits
