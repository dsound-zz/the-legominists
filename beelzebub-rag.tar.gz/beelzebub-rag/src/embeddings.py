"""
Embeddings: Turns text chunks into vectors using OpenAI's embedding model.

Analogy: Each chunk gets a unique "fingerprint" — a list of 1536 numbers
that captures its meaning. Similar meanings → similar fingerprints →
that's how we find relevant passages later.
"""

from openai import OpenAI

from src.chunker import Chunk


# OpenAI recommends batches of ~2000 for the small model
BATCH_SIZE = 500


def embed_chunks(
    chunks: list[Chunk],
    model: str = "text-embedding-3-small",
) -> list[list[float]]:
    """
    Embed all chunks in batches. Returns a list of vectors
    in the same order as the input chunks.
    """
    client = OpenAI()  # uses OPENAI_API_KEY from env
    all_embeddings: list[list[float]] = []

    for i in range(0, len(chunks), BATCH_SIZE):
        batch = chunks[i:i + BATCH_SIZE]
        texts = [c.text for c in batch]

        response = client.embeddings.create(
            input=texts,
            model=model,
        )

        batch_embeddings = [item.embedding for item in response.data]
        all_embeddings.extend(batch_embeddings)

        print(f"  Embedded batch {i // BATCH_SIZE + 1}"
              f" ({len(all_embeddings)}/{len(chunks)} chunks)")

    return all_embeddings
