"""
LLM: Sends retrieved chunks + your question to Claude for a grounded answer.

This is the "mixing console" — it takes the raw tracks (retrieved passages)
and your question, then Claude produces the final mix (a cited answer).
"""

import anthropic


def ask_with_context(
    question: str,
    context_chunks: list[dict],
    model: str = "claude-sonnet-4-20250514",
    max_tokens: int = 1024,
) -> str:
    """
    Send a question to Claude along with retrieved context chunks.
    Each chunk includes its page number for citation.
    """
    # Format context with page numbers for citation
    context_parts = []
    for i, chunk in enumerate(context_chunks, 1):
        context_parts.append(
            f"[Source {i} — Page {chunk['page_number']}]\n{chunk['text']}"
        )
    context_block = "\n\n---\n\n".join(context_parts)

    system_prompt = """You are a scholarly assistant helping analyze Gurdjieff's 
"Beelzebub's Tales to His Grandson." You have been given relevant passages 
from the book. 

Rules:
- Answer based ONLY on the provided passages
- Always cite page numbers: (p. XX)
- If the passages don't contain enough info, say so honestly
- Preserve Gurdjieff's specific terminology (don't simplify his coined words)
- Be precise but accessible"""

    user_message = f"""Here are relevant passages from the book:

{context_block}

---

Question: {question}"""

    client = anthropic.Anthropic()  # uses ANTHROPIC_API_KEY from env

    response = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=system_prompt,
        messages=[{"role": "user", "content": user_message}],
    )

    return response.content[0].text
